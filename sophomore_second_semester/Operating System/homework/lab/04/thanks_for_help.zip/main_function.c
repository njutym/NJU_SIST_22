#include "myos.h"

int main(void)
{   while(1)
   {
     write("hello",5);
     sleep(1);
   }

}