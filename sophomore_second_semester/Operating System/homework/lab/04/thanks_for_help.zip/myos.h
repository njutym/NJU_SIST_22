#ifndef MYOS_H
#define MYOS_H
// 声明write函数原型
void write(char *msg, short len);
// 声明sleep函数原型
void sleep(short seconds);
#endif /* MYOS_H */